package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class LoginPage {
    private final WebDriver driver;

    private final By email = By.id("Email");
    private final By password = By.id("Password");
    private final By loginButton = By.cssSelector("input.login-button");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void login(String mail, String pass) {
        driver.findElement(email).sendKeys(mail);
        driver.findElement(password).sendKeys(pass);
        driver.findElement(loginButton).click();
        try {
            new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@class='account'][text()='" + mail + "']")));
        } catch (Exception ignored) {
        }
        Assert.assertTrue(driver.findElement(By.xpath("//a[@class='account'][text()='" + mail + "']")).isDisplayed(), "Login not successful");
    }
}
