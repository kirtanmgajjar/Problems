package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class SearchPage {
    private final WebDriver driver;

    private final By searchBox = By.id("small-searchterms");
    private final By searchButton = By.cssSelector("input[value='Search']");
    private final By booksLink = By.linkText("Books");
    private final By booksTitle = By.xpath("//div[@class='page-title'][./h1='Books']");

    public SearchPage(WebDriver driver) {
        this.driver = driver;
    }

    public void searchBook(String bookName) {
        driver.findElement(searchBox).sendKeys(bookName);
        driver.findElement(searchButton).click();
        driver.findElement(booksLink).click();
        try {
            new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOfElementLocated((booksTitle)));
        } catch (Exception ignored) {
        }
        Assert.assertTrue(driver.findElement(booksTitle).isDisplayed(), "Books Title was not displayed");
    }
}
