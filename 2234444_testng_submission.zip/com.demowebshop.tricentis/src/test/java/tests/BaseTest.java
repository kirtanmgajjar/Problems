package tests;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import org.testng.ITestResult;
import org.testng.annotations.*;
import utils.DriverUtils;
import utils.ExtentManager;

import java.lang.reflect.Method;

public class BaseTest {
    protected static ExtentReports extent;
    protected ThreadLocal<ExtentTest> test = new ThreadLocal<>();

    @BeforeClass(alwaysRun = true)
    public void initExtent() {
        if (extent == null) {
            extent = ExtentManager.getInstance();  // initialize only once
        }
    }

    @BeforeMethod(alwaysRun = true)
    public void setup(Method method) {
        DriverUtils.initDriver();
        ExtentTest extentTest = extent.createTest(method.getName());
        test.set(extentTest);
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            test.get().fail(result.getThrowable());
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            test.get().pass("Test Passed");
        } else {
            test.get().skip("Test Skipped");
        }

        DriverUtils.quitDriver();
    }

    @AfterClass(alwaysRun = true)
    public void flushExtent() {
        if (extent != null) {
            extent.flush();
        }
    }
}
