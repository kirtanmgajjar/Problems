package tests;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.RegistrationPage;
import pages.SearchPage;
import utils.DriverUtils;

import java.util.concurrent.ThreadLocalRandom;

public class DemoWebShopTests extends BaseTest {

    @Test(priority = 1, groups = "registration")
    public void registrationTest() {
        DriverUtils.getDriver().get("http://demowebshop.tricentis.com/register");
        RegistrationPage reg = new RegistrationPage(DriverUtils.getDriver());
        reg.register("John", "Doe", "john" + generateRandomAlphaNumeric(20) + "@mail.com", "Password123");
        test.get().info("Registration completed");
    }

    @Test(priority = 2, groups = "login", dataProvider = "loginData")
    public void loginTest(String username, String password) {
        DriverUtils.getDriver().get("http://demowebshop.tricentis.com/login");
        LoginPage login = new LoginPage(DriverUtils.getDriver());
        login.login(username, password);
        test.get().info("Login executed for: " + username);
    }

    @DataProvider(name = "loginData", parallel = true)
    public Object[][] loginData() {
        return new Object[][]{
                {"john10@mail.com", "Password123"},
                {"john10@mail.com", "Password123"}
        };
    }

    @Test(priority = 3, groups = "search", invocationCount = 2)
    public void searchTest() {
        DriverUtils.getDriver().get("http://demowebshop.tricentis.com/");
        SearchPage search = new SearchPage(DriverUtils.getDriver());
        search.searchBook("Computer");
        test.get().info("Search executed for Computer Books");
    }

    public String generateRandomAlphaNumeric(int length) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int index = ThreadLocalRandom.current().nextInt(chars.length());
            sb.append(chars.charAt(index));
        }
        return sb.toString();
    }

}
