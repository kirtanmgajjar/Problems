import random
from faker import Faker


def user_detail(num):

    for i in range(num):
        fake = Faker()
        #first_name = randominfo.get_first_name(gender=random.choice(["Male","Female"]))
        first_name = fake.first_name()
        last_name = fake.last_name()
        email = fake.email()
        password = int("".join(random.sample([str(x) for x in range(10)],6)))
        commission = random.randint(10,20)
        roles = random.sample([2,3,4,7,8,11,12],random.randint(1,3))
        address = fake.address()
        city = fake.city()
        state = fake.state()
        phone = int(str(random.randint(6,9)) + "".join(random.sample([str(random.randint(0,9)) for x in range(10)],9)))
        zip_code = fake.zipcode()
        country = fake.country()
        gdpr_consent_status = random.randint(0,1)
        data = {"first_name":first_name,
                "last_name":last_name,
                "email":email,
                "password":password,
                "commission":commission,
                "roles":roles,
                "address":address,
                "city":city,
                "state":state,
                "phone":phone,
                "zip_code":zip_code,
                "country":country,
                "gdpr_consent_status":gdpr_consent_status
                }

        print(data)

if __name__=="__main__":
    user_detail(6)